<!DOCTYPE html>
<html lang="en">

<head>
    <title>Demo</title>
    <link rel="shortcut icon" type="image/png" href="assets/images/Logo.png">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://kit.fontawesome.com/c6673ec9f5.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./assets/scss/main.min.css">
</head>

<body>
    <main>
        <header class="header">
            <div class="container">
                <div class="row">
                    <div class="col-xl-4">
                        <a href="index.php" class="header__brand">Start Bootstrap</a>
                    </div>
                    <div class="col-xl-8">
                        <ul class="nav">
                            <li class="nav-item"><a href="#" class="nav-link">SERVICES</a></li>
                            <li class="nav-item"><a href="#" class="nav-link">PORTFOLIO</a></li>
                            <li class="nav-item"><a href="#" class="nav-link">ABOUT</a></li>
                            <li class="nav-item"><a href="#" class="nav-link">TEAM</a></li>
                            <li class="nav-item"><a href="#" class="nav-link">CONTACT</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </header>
        <!-- Header End -->
        <section class="banner text-center">
            <div class="banner__subtext">Welcome To Our Studio!</div>
            <div class="banner__maintext">It's Nice To Meet You</div>
            <a href="#" class="btn bx-tn btn-primary text-uppercase">Tell Me More</a>
        </section>
        <!-- Banner End -->
        <section class="services text-center">
            <h2 class="title text-uppercase">services</h2>
            <p class="pera">Lorem ipsum dolor sit amet consectetur adipisicing elit</p>
            <div class="container services__box">
                <div class="row">
                    <div class="col-xl-4">
                        <i class="fas fa-cart-arrow-down"></i>
                        <h2>E-Commerce</h2>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nesciunt facere voluptates
                            repudiandae
                        </p>
                    </div>
                    <div class="col-xl-4">
                        <i class="fas fa-laptop"></i>
                        <h2>Responsive Design</h2>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nesciunt facere voluptates
                            repudiandae
                        </p>
                    </div>
                    <div class="col-xl-4">
                        <i class="fas fa-lock"></i>
                        <h2>Web Security</h2>
                        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Nesciunt facere voluptates
                            repudiandae
                        </p>
                    </div>
                </div>
            </div>
        </section>
        <!-- Services End -->
        <section class="portfolio text-center">
            <h2 class="title text-uppercase">Portfolio</h2>
            <p class="pera">Lorem ipsum dolor sit amet consectetur adipisicing elit</p>
            <div class="container mt-5 portfolio__box">
                <div class="row">
                    <div class="col-xl-4  ">
                        <div class="card">
                            <span><img class="img-fluid" src="assets/img/portfolio/1.jpg" alt="..."></span>
                            <h2>E-Commerce</h2>
                            <p>Lorem ipsum
                            </p>
                        </div>
                    </div>
                    <div class="col-xl-4 ">
                        <div class="card">
                            <span><img class="img-fluid" src="assets/img/portfolio/2.jpg" alt="..."></span>
                            <h2>Responsive Design</h2>
                            <p>Lorem ipsum
                            </p>
                        </div>
                    </div>
                    <div class="col-xl-4 ">
                        <div class="card">
                            <span><img class="img-fluid" src="assets/img/portfolio/3.jpg" alt="..."></span>
                            <h2>Web Security</h2>
                            <p>Lorem ipsum
                            </p>
                        </div>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col-xl-4  ">
                        <div class="card">
                            <span><img class="img-fluid" src="assets/img/portfolio/4.jpg" alt="..."></span>
                            <h2>E-Commerce</h2>
                            <p>Lorem ipsum
                            </p>
                        </div>
                    </div>
                    <div class="col-xl-4 ">
                        <div class="card">
                            <span><img class="img-fluid" src="assets/img/portfolio/5.jpg" alt="..."></span>
                            <h2>Responsive Design</h2>
                            <p>Lorem ipsum
                            </p>
                        </div>
                    </div>
                    <div class="col-xl-4 ">
                        <div class="card">
                            <span><img class="img-fluid" src="assets/img/portfolio/6.jpg" alt="..."></span>
                            <h2>Web Security</h2>
                            <p>Lorem ipsum
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Portfolio End -->
        <section class="about text-center">
            <h2 class="title text-uppercase">About</h2>
            <p class="pera">Lorem ipsum dolor sit amet consectetur adipisicing elit</p>
            <div class="container">
                <div class="timeline">
                    <div class="timeline__content">
                        <div class="text">
                            <h2>2017</h2>
                            <h2>Our Humble Beginnings</h2>
                            <p>Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec admodum perfecto
                                mnesarchum, vim ea mazim fierent detracto. Ea quis iuvaret expetendis his, te elit
                                voluptua dignissim per, habeo iusto primis ea eam.</p>
                        </div>
                        <div class="image"><img class="rounded-circle img-fluid" src="assets/img/about/1.jpg" alt="...">
                        </div>
                    </div>
                    <div class="right timeline__content">
                        <div class="text">
                            <h2>2016</h2>
                            <h2>Our Humble Beginnings</h2>
                            <p>Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec admodum perfecto
                                mnesarchum, vim ea mazim fierent detracto. Ea quis iuvaret expetendis his, te elit
                                voluptua dignissim per, habeo iusto primis ea eam.</p>
                        </div>
                        <div class="image"><img class="rounded-circle img-fluid" src="assets/img/about/2.jpg" alt="...">
                        </div>
                    </div>
                    <div class="timeline__content">
                        <div class="text">
                            <h2>2015</h2>
                            <h2>Our Humble Beginnings</h2>
                            <p>Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec admodum perfecto
                                mnesarchum, vim ea mazim fierent detracto. Ea quis iuvaret expetendis his, te elit
                                voluptua dignissim per, habeo iusto primis ea eam.</p>
                        </div>
                        <div class="image"><img class="rounded-circle img-fluid" src="assets/img/about/3.jpg" alt="...">
                        </div>
                    </div>
                    <div class="right timeline__content">
                        <div class="text">
                            <h2>2012</h2>
                            <h2>Our Humble Beginnings</h2>
                            <p>Lorem ipsum dolor sit amet, quo ei simul congue exerci, ad nec admodum perfecto
                                mnesarchum, vim ea mazim fierent detracto. Ea quis iuvaret expetendis his, te elit
                                voluptua dignissim per, habeo iusto primis ea eam.</p>
                        </div>
                        <div class="image"><img class="rounded-circle img-fluid" src="assets/img/about/4.jpg" alt="...">
                        </div>
                    </div>

                    <div class="timeline__content">
                        <div class="image">
                            <h4>Be Part<br> Of Our <br> Story! </h4>
                        </div>
                    </div>
                </div>

            </div>
            </div>
        </section>
        <!-- About End -->
        <section class="page text-center">
            <h2 class="title text-uppercase">Our Amazing Team</h2>
            <p class="pera">Lorem ipsum dolor sit amet consectetur adipisicing elit</p>
            <div class="container mt-5 ">
                <div class="row page__box">
                    <div class="col-xl-4  ">
                        <img class="mx-auto rounded-circle" src="assets/img/team/1.jpg" alt="...">
                        <h2>E-Commerce</h2>
                        <p>Lorem ipsum
                        </p>
                        <a href=""><i class="fab fa-twitter"></i></a>
                        <a href=""><i class="fab fa-facebook-f"></i></a>
                        <a href=""><i class="fab fa-linkedin-in"></i></a>
                    </div>
                    <div class="col-xl-4 ">
                        <img class="mx-auto rounded-circle" src="assets/img/team/2.jpg" alt="...">
                        <h2>Responsive Design</h2>
                        <p>Lorem ipsum
                        </p>
                        <a href=""><i class="fab fa-twitter"></i></a>
                        <a href=""><i class="fab fa-facebook-f"></i></a>
                        <a href=""><i class="fab fa-linkedin-in"></i></a>
                    </div>
                    <div class="col-xl-4 ">
                        <img class="mx-auto rounded-circle" src="assets/img/team/3.jpg" alt="...">
                        <h2>Web Security</h2>
                        <p>Lorem ipsum
                        </p>
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href=""><i class="fab fa-linkedin-in"></i></a>
                    </div>
                </div>
                <p class="pera page--bottom">Lorem ipsum dolor sit amet consectetur adipisicing elit. Accusamus
                    illo, neque error, nihil natus nobis quaerat odio, accusantium autem incidunt maiores ipsa quas
                    saepe facere at amet hic quis vitae!</p>
        </section>
        <!-- Page End -->
        <section class="brand">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3  img-brand"> <a href=""><img class="img-fluid  d-block m-auto "
                                src="assets/img/logos/microsoft.svg" alt="..."></a></div>
                    <div class="col-lg-3 img-brand"><a href=""><img class="img-fluid d-block m-auto "
                                src="assets/img/logos/google.svg" alt="..."></a></div>
                    <div class="col-lg-3 img-brand"> <a href=""><img class="img-fluid d-block m-auto "
                                src="assets/img/logos/facebook.svg" alt="..."></a></div>
                    <div class="col-lg-3 img-brand"><a href=""><img class="img-fluid d-block m-auto"
                                src="assets/img/logos/ibm.svg" alt="..."></a></div>
                </div>
            </div>
        </section>
        <!-- brand End -->
        <section class="contact text-center">
            <h2 class="title contact--ligter text-uppercase">Contact Us</h2>
            <p class="pera ">Lorem ipsum dolor sit amet consectetur adipisicing elit</p>
            <div class="container">
                <form>
                    <div class="row">
                        <div class="col-xl-6">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Your Name *">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Your Email *">
                            </div>
                            <div class="form-group">
                                <input type="tel" class="form-control" placeholder="Your Phone *">
                            </div>
                        </div>
                        <div class="col-xl-6">
                            <div class="form-group">
                                <textarea class="form-control" id="" placeholder="Textarea *" rows="6"></textarea>
                            </div>
                        </div>
                    </div>
                    <a href="#" class="btn bx-tn btn-primary mt-4 text-uppercase disabled">Send Message</a>
                </form>
            </div>
        </section>
        <!-- Contact End -->
        <footer class="footer">
            <div class="container">
                <div class="row py-5">
                    <div class="col-xl-4 ">Copyright © Your Website 2021</div>
                    <div class="col-xl-4 footer__social text-center">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-facebook-f"></i></a>
                        <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    </div>
                    <div class="col-xl-4 ">
                        <a class="link-dark text-decoration-none mr-3" href="#!">Privacy Policy</a>
                        <a class="link-dark text-decoration-none" href="#!">Terms of Use</a>
                    </div>
                </div>
            </div>
        </footer>
    </main>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous">
    </script>
</body>

</html>