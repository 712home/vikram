!(function () {
    'use strict';
    module.exports = function (grunt){
        const sass = require('node-sass');

        grunt.initConfig({
            pkg: grunt.file.readJSON('package.json'),
            sass: {
                dist: {
                    files: {
                        'assets/scss/main.min.css': 'assets/scss/main.scss'   
                    }
                },
                options: {
                    implementation: sass,
                    sourceMap:true,
                    outputStyle: 'compressed',
                },
            },
            watch: {
                sass: {
                    files: [                        
                        'assets/scss/***/*.scss',
                        'assets/scss/**/*.scss',
                        'assets/scss/*/*.scss',
                        'assets/scss/*.scss',
                        ['Gruntfile.js']
                    ],
                    tasks:['sass']
                },

               
            }
        });
        grunt.loadNpmTasks('grunt-sass');
        grunt.loadNpmTasks('grunt-contrib-watch');
        grunt.registerTask('default', ['sass','watch']);
    };
})();